=== AI Content Generator for WP ===
Contributors: arifnezami
Tags: AI, Chatgpt
Requires at least: 4.7
Tested up to: 6.5.3
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Simple AI content generator with OpenAI API.